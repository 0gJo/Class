/**
 *  cookie.js
 */

function delCookie( name ){
	// name  쿠키 존재 X 
	if( !getCookie(name) ){	
		var now = new Date();
		now.setDate( now.getDate()  - 1 );			  
		document.cookie = 
				  name +"=; expires=" + now.toUTCString();
	}
}

function getCookie( name ){	
	 var cookies = document.cookie;	  
	 var arr =  cookies.split("; ");
	   for (var i = 0; i < arr.length; i++) {
		    entry = arr[i];
		    var nv = entry.split("=");
		    if( nv[0] == name ) {
		    	return  unescape( nv[1] ) ;
		    }
	   }	   
	   return null;
}

function setCookie( name, value, exdays ){
	var now = new Date();
	now.setDate( now.getDate()  + exdays );
	// now.setTime( now.getTime() + 1000 * 60 *60 *24 * exdays )
	  
	document.cookie = 
		  name +"="+escape(value) +"; expires=" + now.toUTCString();
	// 기본 :  path=/webPro/javascript/days10
	// path=/
}